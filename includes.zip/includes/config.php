<?php 

define('SITE_NAME', 'Cut your URL');
define('HOST', "http://" . $_SERVER['HTTP_HOST']. "/HTML");
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'gloacademy_cut_url');
define('DB_USER', 'root');
define('DB_PASS', '');

session_start();


//const DB_HOST = '127.0.0.1';
